"""
procesar_excel.py — Convierte Excels EPM en JSON para la app web.
Se ejecuta automáticamente en GitHub Actions al subir un Excel nuevo.

Uso manual:
    python3 scripts/procesar_excel.py
"""
import pandas as pd
import json, gzip, base64, glob, os, re
from datetime import datetime

DATA_DIR   = os.path.join(os.path.dirname(__file__), '..', 'data')
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'docs')
os.makedirs(OUTPUT_DIR, exist_ok=True)

def limpiar_precio(v):
    if pd.isna(v): return None
    s = str(v).strip()
    if s in ['—', '', 'nan', 'TARIFA 2026', 'COD PROPIO']: return None
    try: return round(float(s), 2)
    except: return None

def procesar_archivo(path):
    print(f'  Procesando: {os.path.basename(path)}')
    df = pd.read_excel(path, sheet_name=0, header=None)

    # Encontrar fila con 'CUPS' en col 1
    header_idx = None
    for i in range(min(15, len(df))):
        v = str(df.iloc[i][1]).upper() if pd.notna(df.iloc[i][1]) else ''
        if 'CUPS' == v.strip():
            header_idx = i
            break
    if header_idx is None:
        # Fallback: buscar en cualquier celda de las primeras filas
        for i in range(min(15, len(df))):
            row_vals = [str(v).upper() for v in df.iloc[i].tolist() if pd.notna(v)]
            if 'CUPS' in row_vals:
                header_idx = i; break

    if header_idx is None:
        print('    ERROR: No se encontró fila de encabezados'); return [], []

    header = df.iloc[header_idx].tolist()

    # Detectar columnas summary (fin del área de prestadores)
    SUMMARY_KW = ['PRECIO', 'AHORRO', 'VAR', 'PRESTADOR MÁS', 'PRESTADOR MAS']
    summary_start = len(header)
    for j, v in enumerate(header):
        vs = str(v).upper() if pd.notna(v) else ''
        if any(k in vs for k in SUMMARY_KW):
            summary_start = j; break

    # Prestadores: columnas pares entre 6 y summary_start (paso 2)
    prest_data = []
    for c in range(6, summary_start, 2):
        v = str(header[c]).strip() if pd.notna(header[c]) else ''
        if v and v != 'nan':
            prest_data.append((c, v))
    prest_cols  = [x[0] for x in prest_data]
    prest_names = [x[1] for x in prest_data]

    # Columnas resumen
    col_mn = col_mx = None
    for j, v in enumerate(header):
        vs = str(v).upper() if pd.notna(v) else ''
        if ('MÍN' in vs or 'MIN' in vs) and 'PRECIO' in vs: col_mn = j
        if ('MÁX' in vs or 'MAX' in vs) and 'PRECIO' in vs: col_mx = j

    # Datos: saltar header + subheader (TARIFA 2026 / COD PROPIO)
    data_start = header_idx + 2
    data = df.iloc[data_start:].reset_index(drop=True)

    records = []
    for _, row in data.iterrows():
        cups = str(row[1]).strip() if pd.notna(row[1]) else ''
        if not cups or cups == 'nan' or len(cups) < 3: continue
        esp = str(row[0]).strip() if pd.notna(row[0]) else ''
        dp  = str(row[2]).strip() if pd.notna(row[2]) else ''
        dr  = str(row[3]).strip() if pd.notna(row[3]) else ''
        er  = str(row[4]).strip() if pd.notna(row[4]) else ''
        precios = {}
        for col, name in zip(prest_cols, prest_names):
            t = limpiar_precio(row[col])
            c = str(row[col+1]).strip() if (col+1 < len(row) and pd.notna(row[col+1])
                and str(row[col+1]) not in ['nan','COD PROPIO']) else ''
            if t is not None: precios[name] = [t, c]
        mn = limpiar_precio(row[col_mn]) if col_mn else None
        mx = limpiar_precio(row[col_mx]) if col_mx else None
        if precios and mn is None:
            vals = [v[0] for v in precios.values()]
            mn, mx = min(vals), max(vals)
        records.append([cups, esp, dp, dr, er, precios, mn, mx])

    print(f'    ✓ {len(records)} registros, {len(prest_names)} prestadores')
    return records, prest_names

def main():
    excels = sorted(glob.glob(os.path.join(DATA_DIR, '*.xlsx')) +
                    glob.glob(os.path.join(DATA_DIR, '*.xls')))
    if not excels:
        print('No se encontraron archivos Excel en data/'); return

    versiones = []
    all_prest = set(); all_esp = set()

    for path in excels:
        nombre = os.path.basename(path)
        anio_m = re.search(r'20\d{2}', nombre)
        anio   = anio_m.group() if anio_m else 'SIN_AÑO'
        records, prest_names = procesar_archivo(path)
        if not records: continue
        for r in records:
            all_prest.update(r[5].keys())
            if r[1] and r[1] not in ['nan','⚠ NO EN RESOLUCIÓN']: all_esp.add(r[1])
        j    = json.dumps(records, ensure_ascii=False, separators=(',',':'))
        comp = gzip.compress(j.encode('utf-8'), compresslevel=9)
        b64  = base64.b64encode(comp).decode('ascii')
        fname = f'data_{anio}.json.gz.b64'
        with open(os.path.join(OUTPUT_DIR, fname), 'w') as f: f.write(b64)
        print(f'    → docs/{fname} ({len(b64)//1024} KB)')
        versiones.append({'anio': anio, 'archivo': nombre,
                          'registros': len(records), 'prestadores': prest_names})

    manifest = {
        'generado': datetime.now().isoformat(),
        'prestadores': sorted(all_prest),
        'especialidades': sorted(all_esp),
        'versiones': versiones
    }
    with open(os.path.join(OUTPUT_DIR, 'manifest.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f'\n✅ {len(versiones)} versión(es) procesadas → docs/')

if __name__ == '__main__':
    main()
