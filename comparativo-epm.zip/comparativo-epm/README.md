# Comparativo de Precios EPM 2026
## Sistema web — GitHub Pages + GitHub Actions

App web para comparar precios de 38 prestadores · Resolución CUPS 2706 de 2025 · SaludEPM

---

## 🚀 Configuración inicial (una sola vez — 10 minutos)

### Paso 1 — Crear cuenta GitHub
Ve a **https://github.com** → Sign up (gratis).

### Paso 2 — Crear repositorio
1. Clic en **"New repository"**
2. Nombre: `comparativo-epm` (o cualquier nombre)
3. Visibilidad: **Public** (necesario para GitHub Pages gratis)
4. Clic **"Create repository"**

### Paso 3 — Subir este proyecto
En la página del repositorio vacío, clic en **"uploading an existing file"**
y arrastra **todos los archivos y carpetas** de este ZIP.

O usando Git en terminal:
```bash
git init
git remote add origin https://github.com/TU_USUARIO/comparativo-epm.git
git add .
git commit -m "Inicio del proyecto"
git push -u origin main
```

### Paso 4 — Activar GitHub Pages
1. En tu repositorio → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **gh-pages** / **/ (root)**
4. Guardar

### Paso 5 — Ejecutar el primer procesamiento
1. Ve a la pestaña **Actions** del repositorio
2. Clic en el workflow **"Procesar Excel y Publicar App"**
3. Clic en **"Run workflow"** → **"Run workflow"**
4. Espera 2-3 minutos

Tu app estará en:
**`https://TU_USUARIO.github.io/comparativo-epm`**

---

## 📊 Actualizar datos (cuando hay nuevo Excel)

1. Ve a tu repositorio en GitHub.com
2. Entra a la carpeta **`data/`**
3. Clic **"Add file"** → **"Upload files"**
4. Sube el nuevo Excel con el año en el nombre:
   - `COMPARATIVO_2025.xlsx`
   - `COMPARATIVO_2026.xlsx`
   - `COMPARATIVO_2027.xlsx` (cuando exista)
5. Clic **"Commit changes"**

GitHub automáticamente:
- Detecta el nuevo archivo
- Procesa el Excel con Python
- Publica la app actualizada en ~2 minutos
- **Mantiene todas las versiones anteriores** para comparar

---

## 🔄 Comparación entre años

La app permite comparar 2025 vs 2026 directamente:
1. Clic en **"⇄ Comparar versiones"**
2. Seleccionar el año base en el desplegable
3. La tabla muestra:
   - **▲ rojo**: precio subió vs año anterior
   - **▼ verde**: precio bajó
   - **NUEVO**: CUPS que no existía en la versión anterior
   - Panel de detalle con precios de ambos años lado a lado

---

## 📁 Estructura del proyecto

```
comparativo-epm/
│
├── .github/
│   └── workflows/
│       └── procesar_y_publicar.yml  ← Automatización GitHub Actions
│
├── data/
│   ├── COMPARATIVO_2026.xlsx        ← Fuente de datos 2026
│   └── COMPARATIVO_2025.xlsx        ← Agregar aquí los de años anteriores
│
├── docs/                            ← App publicada (generada automáticamente)
│   ├── index.html                   ← Interfaz principal
│   ├── manifest.json                ← Metadata de versiones disponibles
│   └── data_2026.json.gz.b64        ← Datos comprimidos por año
│
├── scripts/
│   └── procesar_excel.py            ← Script de conversión Excel → JSON
│
└── README.md
```

---

## 🛠 Modificar la interfaz

La app completa está en `docs/index.html`.

**Cambiar colores:**
```css
:root {
  --accent: #58a6ff;   /* azul principal */
  --green:  #3fb950;   /* precio más barato */
  --red:    #f78166;   /* precio más caro */
  --yellow: #e3b341;   /* variación de precio */
  --purple: #bc8cff;   /* comparación entre años */
}
```

**Cambiar título:**
Buscar `Comparativo de Precios` en `docs/index.html`.

---

## ❓ Preguntas frecuentes

**¿Cuánto cuesta?**
Cero. GitHub Pages y GitHub Actions son gratuitos para repositorios públicos.

**¿Quién puede ver la app?**
Cualquier persona con el link. Si necesitas restricción de acceso, se puede configurar autenticación adicional.

**¿El Excel se publica en internet?**
No. Solo se publican los datos procesados en formato JSON comprimido. El Excel original queda en el repositorio privado si así lo configuras.

**¿Cuántas versiones puede tener?**
Ilimitadas. Cada Excel con un año diferente en el nombre agrega una versión nueva.

**¿Cómo agrego 2025 para comparar con 2026?**
Sube `COMPARATIVO_2025.xlsx` a la carpeta `data/` y GitHub lo procesa automáticamente.
